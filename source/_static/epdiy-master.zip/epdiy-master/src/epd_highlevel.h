#pragma once
// This file is only used in the Arduino IDE
// and just includes the IDF component header.

#ifdef __cplusplus
extern "C" {
#endif

#include "epd_driver/include/epd_highlevel.h"

#ifdef __cplusplus
}
#endif
