# LilyGo T5 4.7 Inch Example

This is an example project to kick-start you using the LilyGo T5 4.7 inch EPaper display.

It also incorporates a few deepsleep methods to show how to use deepsleep to effectively save battery.
Additionally, it inherits and modifies the battery calculation code provided in examples by the manufacturer.
