A demo showing a Full-Screen Image
==================================

*The image size is chosen to fit a 1200 * 825 display!*

Image by David REVOY / CC BY (https://creativecommons.org/licenses/by/3.0)
https://commons.wikimedia.org/wiki/File:Durian_-_Sintel-wallpaper-dragon.jpg
